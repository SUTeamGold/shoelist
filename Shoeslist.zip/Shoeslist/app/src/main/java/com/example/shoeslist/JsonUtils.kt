package com.example.shoeslist

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object JsonUtils {
    fun parseShoesJson(context: Context): List<Shoe> {
        val jsonString = context.assets.open("products.json").bufferedReader().use { it.readText() }
        val gson = Gson()
        val shoeType = object : TypeToken<List<Shoe>>() {}.type
        return gson.fromJson(jsonString, shoeType)
    }
}