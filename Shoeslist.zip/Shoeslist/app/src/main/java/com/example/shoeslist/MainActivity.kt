package com.example.shoeslist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shoeslist.JsonUtils.parseShoesJson
import java.io.Serializable

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val shoesList = parseShoesJson(this)
        Log.d("MainActivity", "Number of shoes: ${shoesList.size}")

        val recyclerView: RecyclerView = findViewById(R.id.shoeRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = ShoesAdapter(shoesList) { shoe ->
            val intent = Intent(this, ShoeDetailActivity::class.java).apply {
                putExtra("SHOE_DETAILS", shoe as Serializable) // Shoe class must implement Serializable
            }
            startActivity(intent)
        }
    }
}
