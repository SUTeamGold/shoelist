package com.example.shoeslist

import java.io.Serializable

data class Shoe(
    val name: String,
    val image: String,
    val price: Int,
    val description: String,
    val brand: String,
    val category: String,
    val countInStock: Int,
    val rating: Double,
    val numReviews: Int
) : Serializable

