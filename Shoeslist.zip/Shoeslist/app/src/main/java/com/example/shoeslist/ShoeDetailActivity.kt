package com.example.shoeslist
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class ShoeDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detailshoes)

        // Retrieve the shoe object passed from MainActivity using non-deprecated method
        val shoe = intent.extras?.getSerializable("SHOE_DETAILS") as? Shoe
        shoe?.let {
            populateShoeDetails(it)
        }
    }

    private fun populateShoeDetails(shoe: Shoe) {
        // Find views and set their values based on the shoe object
        val mediaImage: ImageView = findViewById(R.id.mediaImage)
        val mediaTitle: TextView = findViewById(R.id.mediaTitle)
        val brandTextView: TextView = findViewById(R.id.brand)
        val ratingTextView: TextView = findViewById(R.id.mediaRate)
        val reviewCountTextView: TextView = findViewById(R.id.mediaRateCount)
        val categoryTextView: TextView = findViewById(R.id.category)
        val stockTextView: TextView = findViewById(R.id.countInStock)
        val descriptionTextView: TextView = findViewById(R.id.mediaOverview)

        mediaTitle.text = shoe.name
        brandTextView.text = shoe.brand
        ratingTextView.text = shoe.rating.toString()
        reviewCountTextView.text = shoe.numReviews.toString()
        categoryTextView.text = shoe.category
        stockTextView.text = if (shoe.countInStock > 0) "In Stock" else "Out of Stock"
        descriptionTextView.text = shoe.description

        // Handling the image
        val resourceId = resources.getIdentifier(shoe.image, "drawable", packageName)
        if (resourceId != 0) {
            mediaImage.setImageResource(resourceId)
        } else {
            // You can set a default image or leave it blank
        }
    }
}
