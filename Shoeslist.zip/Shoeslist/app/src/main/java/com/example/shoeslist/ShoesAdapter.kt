package com.example.shoeslist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ShoesAdapter(
    private val shoesList: List<Shoe>,
    private val onItemClick: (Shoe) -> Unit
) : RecyclerView.Adapter<ShoesAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val mediaImage: ImageView = view.findViewById(R.id.mediaImage)
        val mediaTitle: TextView = view.findViewById(R.id.mediaTitle)
        val price: TextView = view.findViewById(R.id.price)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_shoes, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val shoe = shoesList[position]
        holder.mediaTitle.text = shoe.name
        holder.price.text = "${shoe.price}"

        // Assuming the image names in the JSON correspond to drawable resource names
        val resourceId = holder.itemView.context.resources.getIdentifier(shoe.image, "drawable", holder.itemView.context.packageName)
        if (resourceId != 0) {
            holder.mediaImage.setImageResource(resourceId)
        } else {
            // Handle the case where the image resource is not found
            // e.g., holder.mediaImage.setImageResource(R.drawable.default_image)
        }

        holder.itemView.setOnClickListener { onItemClick(shoe) }
    }

    override fun getItemCount(): Int {
        return shoesList.size
    }
}
